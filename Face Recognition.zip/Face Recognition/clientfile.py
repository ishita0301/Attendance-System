from this import s
from tkinter import *
from socket import *
import _thread

class Client:
    global s
    # initialize server connection
    def initialize_client(self):
        # initialize socket
        s = socket(AF_INET, SOCK_STREAM)
        # config details of server
        host = 'localhost'  ## to use between devices in the same network eg.192.168.1.5
        port = 1234
        # connect to server
        s.connect((host, port))

        return s


    # update the chat log
    def update_chat(self,msg, state):
        global chatlog

        chatlog.config(state=NORMAL)
        # update the message in the window
        if state == 0:
            chatlog.insert(END, 'YOU: ' + msg)
        else:
            chatlog.insert(END, 'OTHER: ' + msg)
        chatlog.config(state=DISABLED)
        # show the latest messages
        chatlog.yview(END)


    # function to send message
    def send(self):
        global textbox
        # get the message
        msg = textbox.get("0.0", END)
        # update the chatlog
        self.update_chat(msg, 0)
        # send the message
        s.send(msg.encode('ascii'))
        textbox.delete("0.0", END)


    # function to receive message
    def receive(self):
        while 1:
            try:
                data = s.recv(1024)
                msg = data.decode('ascii')
                if msg != "":
                    update_chat(msg, 1)
            except:
                pass


    def press(self,event):
        self.send()


    # GUI function
    def __init__(self,root):
        self.root=root
        global chatlog
        global textbox

        # initialize tkinter object
        
        # set title for the window
        self.root.title("Client Chat")
        # set size for the window
        self.root.geometry("380x430")

        # text space to display messages
        chatlog = Text(self.root, bg='white')
        chatlog.config(state=DISABLED)

        # button to send messages
        sendbutton = Button(self.root, bg='orange', fg='red', text='SEND', command=self.send)

        # textbox to type messages
        textbox = Text(self.root, bg='white')

        # place the components in the window
        chatlog.place(x=6, y=6, height=386, width=370)
        textbox.place(x=6, y=401, height=20, width=265)
        sendbutton.place(x=300, y=401, height=20, width=50)

        # bind textbox to use ENTER Key
        textbox.bind("<KeyRelease-Return>", self.press)

        # create thread to capture messages continuously
        _thread.start_new_thread(self.receive, ())


if __name__ == '__main__':
    root=Tk()
    obj=Client(root)
    root.mainloop()