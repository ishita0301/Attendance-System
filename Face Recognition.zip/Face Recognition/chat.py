from http import server
from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import os
from tkinter import Toplevel
from serverfile import Server
from clientfile import Client 

class Chat:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("Chat")

        title_lbl=Label(self.root,text="CHAT",font=("times new roman",38,"bold"),bg="black",fg="white")
        title_lbl.place(x=0,y=0,width=1300,height=48)

        img=Image.open(r"college_images\chat.png")
        img=img.resize((1300,680),Image.ANTIALIAS)
        self.photoimg_top=ImageTk.PhotoImage(img)

        bg_img=Label(self.root,image=self.photoimg_top)
        bg_img.place(x=0,y=48,width=1300,height=680)

        # .............BUTTONS..............
        # STUDENT BUTTON
        img1=Image.open(r"college_images\face.jpg")
        img1=img1.resize((250,250),Image.ANTIALIAS)
        self.photoimg1=ImageTk.PhotoImage(img1)

        b1=Button(bg_img,image=self.photoimg1,cursor="hand2",command=self.student_chat)
        b1.place(x=150,y=100,width=250,height=250)

        b1_1=Button(bg_img,text="STUDENT ",cursor="hand2",command=self.student_chat,font=("times new roman",20,"bold"),bg="black",fg="white")
        b1_1.place(x=150,y=325,width=250,height=40) 


        # TEACHER BUTTON
        img2=Image.open(r"college_images\teacher.jpg")
        img2=img2.resize((250,250),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        b1=Button(bg_img,image=self.photoimg2,cursor="hand2",command=self.teacher_chat)
        b1.place(x=880,y=335,width=250,height=250)

        b1_1=Button(bg_img,text="TEACHER",cursor="hand2",command=self.teacher_chat,font=("times new roman",20,"bold"),bg="black",fg="white")
        b1_1.place(x=880,y=555,width=250,height=40)  

    def teacher_chat(self):
        self.new_window=Toplevel(self.root)
        self.app=Server(self.new_window)

    def student_chat(self):
        self.new_window=Toplevel(self.root)
        self.app=Client(self.new_window)

if __name__=="__main__":
    root=Tk()
    obj=Chat(root)
    root.mainloop()